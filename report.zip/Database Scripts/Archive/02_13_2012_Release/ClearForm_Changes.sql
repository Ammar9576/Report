alter table nbc_Cust.search add IS_STICKY varchar2(50);

update nbc_cust.search set is_sticky='STICKY' where search_id in (select a.search_id from nbc_cust.search a, (select report_name,user_id, max(searchdate) searchdate From nbc_cust.search where name is null group by report_name,user_id) b
where a.searchdate=b.searchdate and a.report_name=b.report_name and a.user_id = b.user_id);

delete NBC_CUST.group_report_asc_template where template_id in (select search_id from nbc_cust.search where is_sticky is null and name is null and template_type='PRIVATE');

delete NBC_CUST.search_search_param where search_id in ((select search_id from nbc_cust.search where is_sticky is null and name is null and template_type='PRIVATE'));

delete nbc_cust.search where is_sticky is null and name is null and template_type='PRIVATE';