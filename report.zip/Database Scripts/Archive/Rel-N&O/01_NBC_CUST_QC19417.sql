CREATE OR REPLACE FORCE VIEW "NBC_CUST"."PLAN_LINK_QUARTER" ("PLAN_LINK_ID", Start_order_no,end_order_no)
AS
select stewardship_plan_link_id,min(cp.order_no) Start_order_no,max(cp.order_no) end_order_no
from nbc_cust.new_plan , calendar_period cp
where stewardship_plan_link_id is not null
and cp.calendar_period_id in(start_qtr_id,end_qtr_id)
and cp.calendar_id=-2
group by stewardship_plan_link_id;