alter table NBC_CUST.report_jobs add EMAIL_FLAG VARCHAR2(1)
alter table NBC_CUST.report_jobs_audit add EMAIL_FLAG VARCHAR2(1)
