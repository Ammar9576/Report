CREATE OR REPLACE FORCE VIEW "NBC_CUST"."FINANCE_REV_GRID_SUM_VW" ("ID", "USER_ID", "SESSION_ID", "PLAN_CLASS", "COMM_TYPE", "DAYPART", "REVENUE", "PREEMPTIBLE", "COL1VALUE", "COL1LABEL", "COL2VALUE", "COL2LABEL", "COL3VALUE", "COL3LABEL", "COL4VALUE", "COL4LABEL", "COL5VALUE", "COL5LABEL", "COL6VALUE", "COL6LABEL", "COL7VALUE", "COL7LABEL", "COL8VALUE", "COL8LABEL", "COL9VALUE", "COL9LABEL", "QUARTER", "QUARTER_START_DATE", "GROUP_BY_1", "GROUP_BY_2", "GROUP_BY_3", "GROUP_BY_4", "GROUP_BY_5", "SORT_LINE_1", "CAPAVAILSDURSUM")
                 AS
  SELECT a.rowid AS ID,
    a.USER_ID,
    a.SESSION_ID,
    a.plan_class,
    a.comm_type,
    a.daypart,
    a.revenue,
    a.preemptible,
    ROUND(a.col1_Value,2),
    a.col1_Label,
    ROUND(a.col2_Value,2),
    a.col2_Label,
    ROUND(a.col3_Value ,2),
    a.col3_Label,
    ROUND(a.col4_Value,2),
    a.col4_Label,
    ROUND(a.col5_Value,2),
    a.col5_Label,
    ROUND(a.col6_Value,2),
    a.col6_Label,
    ROUND(a.col7_Value,2),
    a.col7_Label,
    ROUND(a.col8_Value,2),
    a.col8_Label,
    ROUND(a.col9_Value,2),
    a.col9_Label,
    a.quarter,
    a.QUARTER_START_DATE,
    a.group_by_1,
    a.group_by_2,
    a.group_by_3,
    a.group_by_4,
    a.group_by_5,
    a.sort_line_1,
    b.capAvailsDursummary
  FROM finance_rev_sum_dynamic_tbl a ,
    (SELECT (ROUND(capacity,2)
      ||'~'
      || ROUND(avails,2)
      ||'~'
      || ROUND(DURATION,2) ) capAvailsDursummary,
      daypart,
      user_id,
      session_id
    FROM finance_revenue_summary_tbl
    WHERE --capacity       IS NOT NULL AND
      SUMMARY_GRID_FLAG =1
    ) b
  WHERE a.user_id    =b.user_id
  AND a.SESSION_ID   =b.SESSION_ID
  AND a.daypart      =b.daypart
  AND a.preemptible IN (0,1)
    --AND a.quarter     != 'Total'
  AND a.comm_type IS NOT NULL;