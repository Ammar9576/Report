create or replace
PROCEDURE                                               NBC_CUST.POPULATE_ISCI_SUMMARY AS
     
    isci_summary_db_rec nbc_cust.isci_summary%rowtype;
    insert_flag number;
        
BEGIN
  DBMS_OUTPUT.PUT_LINE('start time-->'||SYSTIMESTAMP);
   FOR comm_vers_rec_var 
   IN (SELECT cv.ISCII,cv.advertiser_id,cv.UNIT_DURATION_CODE,cvm.approval,cvm.restricted,cvm.MEDIAVU_RESTRICTIONS,cvm.comments,cvm.mediavu_product_name,cvm.mediavu_category_name,cvm.approved_on,cvm.approved_by
    FROM onair.comm_version cv,
    nbc_cust.comm_version_mediavu_status cvm
   WHERE 
    cv.ARCHIVED_CODE = 1351000
    and cv.comm_version_id=cvm.comm_version_id)
   LOOP
   insert_flag:=0;
   --DBMS_OUTPUT.PUT_LINE(comm_vers_rec_var.mediavu_product_name||comm_vers_rec_var.mediavu_category_name);
   begin
   select * into isci_summary_db_rec from nbc_cust.isci_summary where isci=comm_vers_rec_var.iscii and rownum=1; 
   
	exception when no_data_found then
	 --insert_flag:=1;
	INSERT INTO nbc_cust.isci_summary
   (ISCI_SUMM_ID,isci,advertiser_id,duration_id,approval,restricted,restrictions,comments,product_name,category_name,approved_by,approved_on)
   VALUES
   ( nbc_cust.isci_summ_seq.nextval,comm_vers_rec_var.ISCII,comm_vers_rec_var.advertiser_id,comm_vers_rec_var.UNIT_DURATION_CODE,comm_vers_rec_var.approval,comm_vers_rec_var.restricted,comm_vers_rec_var.MEDIAVU_RESTRICTIONS,comm_vers_rec_var.comments,comm_vers_rec_var.mediavu_product_name,comm_vers_rec_var.mediavu_category_name,comm_vers_rec_var.approved_by,comm_vers_rec_var.approved_on);
	--DBMS_OUTPUT.PUT_LINE('no data');
  end;
   --if(insert_flag=0) then
 update nbc_cust.isci_summary set
   isci=comm_vers_rec_var.ISCII,advertiser_id=comm_vers_rec_var.advertiser_id,duration_id=comm_vers_rec_var.UNIT_DURATION_CODE,approval=comm_vers_rec_var.approval,restricted=comm_vers_rec_var.restricted,restrictions=comm_vers_rec_var.MEDIAVU_RESTRICTIONS,comments=comm_vers_rec_var.comments,product_name=comm_vers_rec_var.mediavu_product_name,category_name=comm_vers_rec_var.mediavu_category_name,approved_by=comm_vers_rec_var.approved_by,approved_on=comm_vers_rec_var.approved_on
   where isci=comm_vers_rec_var.iscii;
  --end
  --end if;
   commit;
   END LOOP;
   
   FOR nmedia_vu_mapping_var 
   IN (SELECT *
    FROM nbc_cust.media_vu_mapping)
   LOOP
    insert_flag:=0;
      --DBMS_OUTPUT.put_line (ISCII);
      --DBMS_OUTPUT.PUT_LINE(nmedia_vu_mapping_var.mediavu_product_name||nmedia_vu_mapping_var.mediavu_category_name);
	   begin
   select * into isci_summary_db_rec from nbc_cust.isci_summary where isci=nmedia_vu_mapping_var.isci and rownum=1; 
	exception when no_data_found then
   --insert_flag:=1;
  INSERT INTO nbc_cust.isci_summary
   ( ISCI_SUMM_ID,isci,advertiser_id,duration_id,approval,restricted,comments,product_name,category_name,approved_by,approved_on)
   VALUES
   
   ( nbc_cust.isci_summ_seq.nextval,nmedia_vu_mapping_var.ISCI,nmedia_vu_mapping_var.ONAIR_ADVERTISER_ID,nmedia_vu_mapping_var.DURATION,nmedia_vu_mapping_var.approval,nmedia_vu_mapping_var.restricted,nmedia_vu_mapping_var.comments,nmedia_vu_mapping_var.mediavu_product_name,nmedia_vu_mapping_var.mediavu_category_name,nmedia_vu_mapping_var.approved_by,nmedia_vu_mapping_var.approved_on);
    end; 
    --if(insert_flag=0) then
	update nbc_cust.isci_summary set isci=nmedia_vu_mapping_var.ISCI,advertiser_id=nmedia_vu_mapping_var.ONAIR_ADVERTISER_ID,duration_id=nmedia_vu_mapping_var.DURATION,approval=nmedia_vu_mapping_var.approval,restricted=nmedia_vu_mapping_var.restricted,comments=nmedia_vu_mapping_var.comments,product_name=nmedia_vu_mapping_var.mediavu_product_name,category_name=nmedia_vu_mapping_var.mediavu_category_name,approved_by=nmedia_vu_mapping_var.approved_by,approved_on=nmedia_vu_mapping_var.approved_on
   where isci=nmedia_vu_mapping_var.isci;
  --end if;
   commit;
   END LOOP;
   DBMS_OUTPUT.PUT_LINE('end time-->'||SYSTIMESTAMP);
END POPULATE_ISCI_SUMMARY;