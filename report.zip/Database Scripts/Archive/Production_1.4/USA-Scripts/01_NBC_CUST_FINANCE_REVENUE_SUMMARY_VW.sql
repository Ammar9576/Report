CREATE OR REPLACE FORCE VIEW "NBC_CUST"."FINANCE_REVENUE_SUMMARY_VW" ("ID", "USER_ID", "SESSION_ID", "DAYPART", "DAYPART_NO", "DAYPART_ID", "CAPACITY", "DURATION", "AVAILS", "SN_CATEGORY")
                 AS
  SELECT a.rowid AS ID,
    a."USER_ID",
    a."SESSION_ID",
    a."DAYPART",
    a."DAYPART_NO",
    a."DAYPART_ID",
    a."CAPACITY",
    a."DURATION",
    a."AVAILS",
    a."SN_CATEGORY"
  FROM nbc_cust.finance_revenue_summary_tbl a;