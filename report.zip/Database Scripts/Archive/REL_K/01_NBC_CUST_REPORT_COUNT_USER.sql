create or replace
FUNCTION          REPORT_JOB_USR_CNT_FUNC 

(
  USER_ID_ IN VARCHAR2
) RETURN NBC_CUST.REPORT_JOB_CNT_C PIPELINED AS 

OUT_REC  NBC_CUST.REPORT_JOB_CNT := NBC_CUST.REPORT_JOB_CNT(0,0,0,0,0,0,0,0,0);

  CURSOR C1 ( USER_ID_  NUMBER)  IS
  
 
   SELECT 1 id,
  SUM(compStOut0)+SUM(compStOut1) completed_count,
  SUM(abortedcount) aborted_Count,
  SUM(runningcount) running_count,
  SUM(EXPIREDCOUNT) EXPIRED_COUNT,
  SUM(COMPSTOUT0) STREAMED_OUT,
  SUM(scheduledcount) scheduled_count,
  SUM(CANCELLEDCOUNT) CANCELLED_COUNT,
  SUM(compStOut0)+SUM(compStOut1)+SUM(runningcount)+SUM(abortedcount)+SUM(scheduledcount) overall_count
FROM
  (SELECT A.ID,
    -- A.JOB_STATUS STATUS,
    a.created_by user_id,
    CASE
      WHEN (DECODE(a.job_status,'COMPLETED',1,0)
        ||NVL(a.streamed_out,0)) = 10
      THEN 1
      ELSE 0
    END compStOut0 ,
    CASE
      WHEN (DECODE(a.job_status,'COMPLETED',1,0)
        ||NVL(a.streamed_out,0)) = 11
      THEN 1
      ELSE 0
    END compStOut1,
    DECODE(a.job_status,'ABORTED',1,0) abortedcount,
    DECODE(a.job_status,'RUNNING',1,0) runningcount,
    DECODE(a.job_status,'SCHEDULED',1,0) scheduledcount,
    DECODE(a.job_status,'CANCELLED',1,0) cancelledcount,
    DECODE(A.JOB_STATUS,'EXPIRED',1,0) EXPIREDCOUNT
  FROM nbc_cust.report_jobs A
  WHERE A.DELETED_FLAG <>1
  AND ( A.SCHEDULE_ID  IN
    (SELECT c.schedule_id
    FROM NBC_CUST.SEARCH PARTITION(SEARCH_ACTIVE) C
    WHERE C.TEMPLATE_TYPE ='PRIVATE'
    AND C.SCHEDULE_ID    IS NOT NULL
    AND C.USER_ID         =USER_ID_
    )
  OR (A.SCHEDULE_ID IS NULL
  AND A.CREATED_BY   =USER_ID_ )
  ));

BEGIN
  
 FOR IN_REC IN C1 (USER_ID_)
   LOOP
    OUT_REC.ID := IN_REC.id;
    
    OUT_REC.COMPLETED_COUNT := IN_REC.COMPLETED_COUNT;
    out_rec.ABORTED_COUNT := in_rec.aborted_Count;
    
    OUT_REC.RUNNING_COUNT := IN_REC.RUNNING_COUNT;
    OUT_REC.EXPIRED_COUNT := IN_REC.EXPIRED_COUNT;     
    
    OUT_REC.STREAMED_OUT := IN_REC.STREAMED_OUT;
     OUT_REC.SCHEDULED_COUNT := IN_REC.SCHEDULED_COUNT;
    OUT_REC.CANCELLED_COUNT := in_rec.CANCELLED_COUNT;
    OUT_REC.OVERALL_COUNT := IN_REC.OVERALL_COUNT;
    
    
    PIPE ROW(out_rec);

   END LOOP;
  
  RETURN;
  
END REPORT_JOB_USR_CNT_FUNC;


CREATE TYPE NBC_CUST.REPORT_JOB_CNT AS OBJECT
( 
  ID  VARCHAR2(100),
  COMPLETED_COUNT  VARCHAR2(100),
  ABORTED_COUNT  VARCHAR2(100),
  RUNNING_COUNT  VARCHAR2(100),
  EXPIRED_COUNT  VARCHAR2(100),
  STREAMED_OUT  VARCHAR2(100),
  SCHEDULED_COUNT  VARCHAR2(100),
  CANCELLED_COUNT  VARCHAR2(100),
  OVERALL_COUNT  varchar2(100));

CREATE TYPE NBC_CUST.REPORT_JOB_CNT_C AS TABLE OF NBC_CUST.REPORT_JOB_CNT;


