CREATE OR REPLACE FORCE VIEW "NBC_CUST"."PLACEMENT_CHNLS_FRM_CHNLGRP_VW"
                 AS
select promo_target_channel.promo_id promo_id, channel.channel_id channel_id
from 
channel_group ,
channel,
promo_target_channel
where 
channel_group.sub_channel_id = channel.channel_id and
promo_target_channel.promo_target_channel_id=channel_group.channel_id;

CREATE OR REPLACE FORCE VIEW "NBC_CUST"."PLACEMENT_CHANNELS_VW"
                 AS
select channel.channel_id,
       promo_target_channel.promo_id
from 
promo_target_channel,
channel
where
promo_target_channel.promo_target_channel_id = channel.channel_id
and group_code='1013000';