update nbc_cust.search 
set report_name='PROPERTY STEWARDSHIP REPORT'
where report_name = 'PROPERTY LIABILITY SUMMARY REPORT'

update nbc_cust.search_audit
set report_name='PROPERTY STEWARDSHIP REPORT'
where report_name = 'PROPERTY LIABILITY SUMMARY REPORT'


update nbc_cust.group_report_assoc 
set report_name='PROPERTY STEWARDSHIP REPORT'
where report_name= 'PROPERTY LIABILITY SUMMARY REPORT'

update nbc_cust.group_report_assoc_audit
set report_name='PROPERTY STEWARDSHIP REPORT'
where report_name= 'PROPERTY LIABILITY SUMMARY REPORT'


update nbc_cust.report_schedules 
set report_name='PROPERTY STEWARDSHIP REPORT'
where report_name= 'PROPERTY LIABILITY SUMMARY REPORT'

update nbc_cust.report_schedules_audit
set report_name='PROPERTY STEWARDSHIP REPORT'
where report_name= 'PROPERTY LIABILITY SUMMARY REPORT'