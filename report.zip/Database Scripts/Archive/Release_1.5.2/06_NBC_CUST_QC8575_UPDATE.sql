Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'UNBRANDED',
	'UNBRANDED'
);
