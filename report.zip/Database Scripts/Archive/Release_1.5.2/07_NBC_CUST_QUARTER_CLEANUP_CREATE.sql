create or replace
FUNCTION QUARTER_CLEANUP RETURN VARCHAR2 AS 

   cursor c1 is
    select sv.id,sv.stringvalue
    from nbc_Cust.search partition(search_active) s,
    NBC_CUST.search_param sp,
    NBC_CUST.search_values sv
    where  s.id =sp.search_id
    and sp.id=sv.parameter_id
    and s.id in (
      select s.id from nbc_Cust.search partition(search_active) s  
      where report_name in ('DAYPART PROJECTIONS REPORT','PLAN STEWARDSHIP REPORT','PROPERTY STEWARDSHIP REPORT','OPTIONS REPORT')
    )
    and sp.name in('toDate','fromDate','startDate','endDate')
    and to_date(to_char(s.created_date,'dd-MON-yyyy'),'dd-MON-yyyy') < to_date('29-JUL-2013','dd-MON-yyyy')
     and to_date(to_char(s.modify_date,'dd-MON-yyyy'),'dd-MON-yyyy') < to_date('29-JUL-2013','dd-MON-yyyy')
    and to_number(dbms_lob.substr(sv.stringvalue, 100, 1 ))<=32
    and to_char(dbms_lob.substr(sv.stringvalue, 100, 1 )) not like '%/%';-- plan stew report had date option prev
   

BEGIN
   
   FOR rec in c1
   loop
      UPDATE nbc_cust.search_values 
      set stringvalue = to_number(dbms_lob.substr(rec.stringvalue, 100, 1 )) +4
      where id =rec.id;
  end loop;
 -- commit;
  RETURN NULL;
END QUARTER_CLEANUP;