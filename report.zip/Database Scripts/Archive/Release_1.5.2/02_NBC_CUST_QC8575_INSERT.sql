/**
 * ../src/domain/security/User.java Constants
 */

Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'VALID_PROPS',
	'BRAVO,CNBC WORLD,CHILLER,SLEUTH,JBC,OXYGEN,UNIVERSAL HD,X-PROPERTY'
);

Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'GENERIC_PROPS',
	'ACCOUNT_EXECUTIVE,AD_SALES,BILLING,COLLECTIONS,COMMERCIAL_OPERATIONS,COPY_EDITOR,CORPORATE_FINANCE,DIRECT_RESPONSE,INFORMATION_TECHNOLOGY,ITV,IT_MIGRATION,IT_MONITORING,IT_SUPPORT,LOG_EDITOR,MASTER_DATA_MANAGEMENT,PLANNING,POST_BUY_EXPORT,PRICING,PROGRAM_SCHEDULER,PROMO_SCHEDULER,PROPERTY_ADMINISTRATOR,READ_ONLY,RESEARCH,SALES_ASSISTANT,SALES_FORCE_SUPPORT,SALES_MANAGEMENT,SALES_PLANNER,SYSTEM_ADMINISTRATOR,WEB_SCHEDULER_SUPPORT,PROGRAMMING'
);

Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'CHANGED_PROPS',
	'SLEUTH~CLOO'
);

/**
 *../src/controller/reference/CustomBrandController.java Constants
 */
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'REVISION_TYPE_OPEN_REVISION',
	'OPEN REVISION'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'REVISION_TYPE_LAST_APPROVED',
	'LAST APPROVED / PRE-HOLD'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'REVISION_TYPE_HOLD_ARCHIVE',
	'HOLD ARCHIVE'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'REVISION_TYPE_ORDER_ARCHIVE',
	'ORDER ARCHIVE'
);
/**
 *../src/controller/reference/CustomLineClassController.java Constants
 */
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'REVISION_TYPE_BY_REVISION_NO',
	'BY REVISION NO.'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'BY_REV_PK_0',
	'select code,description from SALES_LINE_CLASS_CVW where code in (select LINE_CLASS_CODE from plan_line_rev_vw where PLAN_ID=:planId)'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'BY_REV_PK_GT_0',
	'select code,description from SALES_LINE_CLASS_CVW where code in (select LINE_CLASS_CODE from PH_PLAN_LINE  where PLAN_ID=:planId And Plan_History_Id = :planHistoryId)'
);
/**
 *../src/com/ge/nbcuni/cir/service/SearchPersistenceService.java Constants
 */
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'ADMIN_GROUP_ID',
	'10'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'PROPOSAL_REPORT',
	'PROPOSAL REPORT'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'FLOWCHART_REPORT',
	'FLOWCHART REPORT'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'CHANGE_NOTICE_REPORT',
	'CHANGE NOTICE REPORT'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'PLAN_OPTIONS_REPORT',
	'PLAN OPTIONS REPORT'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'PRIVATE',
	'PRIVATE'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'NON_RATED',
	'non-rated'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'FROM_PLAN',
	'from plan'
);


/**
 *../src/com/ge/nbcuni/cir/service/ReportJobPersistenceService.java Constants
 *
 **/

Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'SCHEDULE_TIME_CHANGE_MSG',
	'Schedule timing was changed by the user'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'SCHEDULE_REMOVED_MSG',
	'Schedule is either removed/ expired!'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'SCHEDULE_TMP_DELETE_MSG',
	'Template is deleted!'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'SYSTEM_USER',
	'-10000'
);


/**
 *../src/com/ge/nbcuni/cir/service/CIRPersistenceService.java Constants
 *
 **/
--Insert into NBC_CUST.CIR_CONSTANTS values 
--(
--	'JOB_ARCHIVAL_QUERY',
--	'select * from nbc_cust.report_jobs where job_status IN ('ABORTED','CANCELLED' , 'COMPLETED', 'DELETED')  and nvl(archived_flag,0) = 0  and  to_date(trim(to_char(created_date, 'dd-mm-yyyy')), 'dd-mm-yyyy')<=to_date(to_char(sysdate-?,'dd-mm-yyyy'), 'dd-mm-yyyy') '
--); 
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'JOB_IMMEDIATE_ARCHIVAL_DAYS',
	'7'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'EXPIRED_SCHEDULE_RETENTION_DAYS',
	'15'
);
/**
 *../src/com/ge/nbcuni/cir/service/FlowchartRevisionTypeController.java Constants
 *
 **/
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'PLAN_STATUS_LOST',
	'LOST'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'PLAN_STATUS_PAST_PLAN',
	'PAST PLAN'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'PLAN_STATUS_RFP',
	'RFP'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'PLAN_STATUS_WS',
	'WORKING SPECULATIVE'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'PLAN_STATUS_WML',
	'WORKING MOST LIKELY'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'PLAN_STATUS_HOLD',
	'HOLD'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'PLAN_APPROVAL_STATUS_APPROVED',
	'APPROVED'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'PLAN_APPROVAL_STATUS_PARTIALLY_APPROVED',
	'PARTIALLY APPROVED'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'PLAN_APPROVAL_STATUS_REJECTED',
	'REJECTED'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'PLAN_APPROVAL_STATUS_OPEN_REVISION',
	'OPEN REVISION'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'PLAN_APPROVAL_STATUS_PENDING_APPROVAL',
	'APPROVAL REQUESTED'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'PLAN_STATUS_ORDER',
	'ORDER'
);
/**
 * ../src/domain/security/PlanHistoryDao.java Constants
 * 
 * Note: This class has not been updated with constantService class
 */
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'PLAN_HIST_FOR_HOLD_ARCHIVE',
	'Select * From (Select Phl.*,  Row_Number() Over(Partition By Ph.Plan_Id Order By Ph.Plan_History_Dt Asc) rk From Plan Pl, Ph_Plan Phl, Plan_History Ph Where 1 = 1 And Pl.Plan_Id=:planId And Pl.Plan_Id = Phl.Plan_Id And (Pl.Hold_Archived_Revision_No <> -1 And Pl.Hold_Archived_Revision_No =Phl.Hold_Archived_Revision_No) And Phl.Plan_History_Id = Ph.Plan_History_Id And Phl.Plan_Id = Ph.Plan_Id) Where Rk = 1'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'PLAN_HIST_FOR_ORDER_ARCHIVE',
	'Select * From (Select Phl.*,  Row_Number() Over(Partition By Ph.Plan_Id Order By Ph.Plan_History_Dt Asc) rk From Plan Pl, Ph_Plan Phl, Plan_History Ph Where 1 = 1 And Pl.Plan_Id=:planId And Pl.Plan_Id = Phl.Plan_Id And (Pl.Contract_Rev_No <> -1 And Pl.Contract_Rev_No = Phl.Contract_Rev_No) And Phl.Plan_History_Id = Ph.Plan_History_Id And Phl.Plan_Id = Ph.Plan_Id) Where Rk = 1'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'PLAN_HIST_FOR_HOLD_ARCHIVE_NEW',
	'Select code,description From Sales_Line_Class_Cvw Where Code In (Select Line_Class_Code From Plan_Hold_Archived_Vw, Ph_Plan_Line Where Plan_Hold_Archived_Vw.Plan_Id = :planId And Plan_Hold_Archived_Vw.Plan_Id = Ph_Plan_Line.Plan_Id And Plan_Hold_Archived_Vw.Plan_History_Id = Ph_Plan_Line.Plan_History_Id)'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'PLAN_HIST_FOR_ORDER_ARCHIVE_NEW',
	'Select code,description From Sales_Line_Class_Cvw Where Code In (Select Line_Class_Code From Plan_Order_Archive_Vw, Ph_Plan_Line Where Plan_Order_Archive_Vw.Plan_Id = :planId And Plan_Order_Archive_Vw.Plan_Id = Ph_Plan_Line.Plan_Id And Plan_Order_Archive_Vw.Plan_History_Id = Ph_Plan_Line.Plan_History_Id)'
);

/**
 *../src/com/ge/nbcuni/cir/service/ProposalRevisionTypeController.java Constants
 *  Note: All constants used in this class have been inserted from above classes.
 **/

/**
 *../src/dao/reference/CustomRevisionTypeDao.java Constants
 *  Note: All constants used in this class have been inserted from above classes.
 **/

/**
 *../src/controller/reference/SalesUnitControllerNew.java Constants
 *  
 **/
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'STR_1464001',
	'1464001'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'STR_1724000',
	'1724000'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'STR_3111001',
	'3111001'
);
Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'STR_3111000',
	'3111000'
);


/**
 *../src/controller/reference/PromoTimingControllerNew.java Constants
 *  
 **/

Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'STR_10046',
	'10046'
);


Insert into NBC_CUST.CIR_CONSTANTS values 
(
	'TARGET_GROUP_HH',
	'HH'
);


