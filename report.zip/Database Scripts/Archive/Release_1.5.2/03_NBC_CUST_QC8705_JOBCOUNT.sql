CREATE OR REPLACE FORCE VIEW "NBC_CUST"."REPORT_JOB_STATISTICS_VW" ("ID", "USER_ID", "COMPLETED_COUNT", "ABORTED_COUNT", "RUNNING_COUNT", "EXPIRED_COUNT", "SCHEDULED_COUNT", "CANCELLED_COUNT", "OVERALL_COUNT", "STREAMED_OUT")
            AS
WITH qblock AS
  (SELECT a.id,
    a.job_status status,
    --nvl(a.streamed_out,0) out,
    a.created_by user_id,
    --decode(a.job_status,'COMPLETED',1,0) completedcount,
    CASE
      WHEN (DECODE(a.job_status,'COMPLETED',1,0)
        ||NVL(a.streamed_out,0)) = 10
      THEN 1
      ELSE 0
    END compStOut0 ,
    CASE
      WHEN (DECODE(a.job_status,'COMPLETED',1,0)
        ||NVL(a.streamed_out,0)) = 11
      THEN 1
      ELSE 0
    END compStOut1,
    DECODE(a.job_status,'ABORTED',1,0) abortedcount,
    DECODE(a.job_status,'RUNNING',1,0) runningcount,
    DECODE(a.job_status,'SCHEDULED',1,0) scheduledcount,
    DECODE(a.job_status,'CANCELLED',1,0) cancelledcount,
    DECODE(a.job_status,'EXPIRED',1,0) expiredcount
  FROM nbc_cust.report_jobs a
  WHERE a.id                 <>-1
  AND a.deleted_flag         <>1
  AND a.schedule_id          IS NULL
  AND NVL(a.archived_flag,0) <>1
  --AND a.created_by    ='18467'
  UNION
  SELECT A.ID,
    a.job_status status ,
    --nvl(a.streamed_out,0) out,
    c.user_id user_id,
    CASE
      WHEN (DECODE(a.job_status,'COMPLETED',1,0)
        ||NVL(a.streamed_out,0)) = 10
      THEN 1
      ELSE 0
    END compStOut0 ,
    CASE
      WHEN (DECODE(a.job_status,'COMPLETED',1,0)
        ||NVL(a.streamed_out,0)) = 11
      THEN 1
      ELSE 0
    END compStOut1,
    --decode(a.job_status,'COMPLETED',1,0)||nvl(a.streamed_out,0) completedcount,
    DECODE(a.job_status,'ABORTED',1,0) abortedcount,
    DECODE(a.job_status,'RUNNING',1,0) runningcount,
    DECODE(a.job_status,'SCHEDULED',1,0) scheduledcount,
    DECODE(a.job_status,'CANCELLED',1,0) cancelledcount,
    DECODE(a.job_status,'EXPIRED',1,0) expiredcount
  FROM nbc_cust.report_jobs a,
    nbc_cust.report_schedules b,
    nbc_Cust.search partition(search_active) c
  WHERE c.schedule_id         =b.id
  AND b.id                    =a.schedule_id
  AND c.template_type         ='PRIVATE'
  AND a.id                   <>-1
  AND a.deleted_flag         <>1
  and nvl(a.archived_flag,0) <>1
  and  NVL(b.deleted_flag,0) <>1
  --AND  c.user_id    ='18467'
  UNION
  SELECT DISTINCT jobs.ID,
    jobs.job_status status,
    --nvl(jobs.streamed_out,0) out,
    usr.user_id user_id,
    --decode(jobs.job_status,'COMPLETED',1,0) completedcount,
    CASE
      WHEN (DECODE(jobs.job_status,'COMPLETED',1,0)
        ||NVL(jobs.streamed_out,0)) = 10
      THEN 1
      ELSE 0
    END compStOut0 ,
    CASE
      WHEN (DECODE(jobs.job_status,'COMPLETED',1,0)
        ||NVL(jobs.streamed_out,0)) = 11
      THEN 1
      ELSE 0
    END compStOut1,
    DECODE(jobs.job_status,'ABORTED',1,0) abortedcount,
    DECODE(jobs.job_status,'RUNNING',1,0) runningcount,
    DECODE(jobs.job_status,'SCHEDULED',1,0) scheduledcount,
    DECODE(jobs.job_status,'CANCELLED',1,0) cancelledcount,
    DECODE(jobs.job_status,'EXPIRED',1,0) expiredcount
  FROM onair.app_user usr
  INNER JOIN lbacsys.sa$user_groups securitygr1_
  ON usr.ident=securitygr1_.usr_name
  INNER JOIN lbacsys.sa$groups securitygr2_
  ON securitygr1_.group#=securitygr2_.group#
  INNER JOIN nbc_cust.group_report_assoc grouprepor3_
  ON securitygr2_.group#=grouprepor3_.group_id
  INNER JOIN nbc_cust.group_report_asc_template templates4_
  ON grouprepor3_.group_report_asc_id=templates4_.group_report_asc_id
  INNER JOIN nbc_Cust.search partition(search_active) search
  ON templates4_.template_id=search.id
  INNER JOIN nbc_cust.report_schedules schedules
  ON schedules.id=search.schedule_id
  INNER JOIN nbc_cust.report_jobs jobs
  ON jobs.schedule_id      =schedules.id
  WHERE search.id         <>-1
  AND search.deleted_flag <>1
  AND search.template_type!='PRIVATE'
    --AND usr.user_id          ='18467'
  AND jobs.id                   <>-1
  AND jobs.deleted_flag         <>1
  and nvl(jobs.archived_flag,0) <>1
  and  NVL(schedules.deleted_flag,0) <>1
  ),
  Temp AS
  (SELECT user_id,
    SUM(compStOut0)+SUM(compStOut1) completed_count,
    SUM(abortedcount) aborted_Count,
    SUM(runningcount) running_count,
    SUM(expiredcount) expired_count,
    SUM(scheduledcount) scheduled_count,
    SUM(cancelledcount) cancelled_count,
    SUM(compStOut0)+SUM(compStOut1)+SUM(runningcount)+SUM(abortedcount)+SUM(scheduledcount) overall_count,
    SUM(compStOut0) streamed_out
  FROM qblock
  GROUP BY user_id
  ORDER BY user_id
  )
SELECT Rownum ,
  temp."USER_ID",
  temp."COMPLETED_COUNT",
  temp."ABORTED_COUNT",
  temp."RUNNING_COUNT",
  temp."EXPIRED_COUNT",
  temp."SCHEDULED_COUNT",
  temp."CANCELLED_COUNT",
  temp."OVERALL_COUNT",
  temp."STREAMED_OUT"
FROM Temp;