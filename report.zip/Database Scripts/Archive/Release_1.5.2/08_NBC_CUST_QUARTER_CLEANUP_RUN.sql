DECLARE
  v_Return VARCHAR2(200);
BEGIN

  v_Return := QUARTER_CLEANUP();
  /* Legacy output: 
DBMS_OUTPUT.PUT_LINE('v_Return = ' || v_Return);
*/ 
  :v_Return := v_Return;
END;
