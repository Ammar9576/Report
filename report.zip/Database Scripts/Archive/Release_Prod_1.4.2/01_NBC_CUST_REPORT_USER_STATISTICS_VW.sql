CREATE OR REPLACE FORCE VIEW "NBC_CUST"."REPORT_USER_STATISTICS_VW" ("ID", "REPORT_NAME", "USER_NAME", "STATUS", "PDF_COUNT", "FMT_EXL_CNT", "UNFMT_EXL_CNT", "COUNT", "RANK")
             AS
WITH Qblock1 AS
  (SELECT S.Report_Name Report,
    Au.User_Name Name,
    Rj.Id,
    Rj.Output_Type,
    DECODE(Rj.Output_Type,'PDF',1,0) Pdfcount,
    DECODE(Rj.Output_Type,'formatExcel',1,0) Formatcount,
    DECODE(Rj.Output_Type,'unformatExcel',1,0) Unformatcount,
    Rj.Job_Status status
  FROM nbc_cust.report_jobs rj ,
    nbc_cust.search s,
    app_user au
  WHERE S.Id           = Rj.Template_Id
  AND Au.User_Id       =Rj.Created_By
  AND Rj.Created_Date >= Add_Months(Sysdate, -3)
    --And Rj.Job_Status='COMPLETED'
  GROUP BY S.Report_Name,
    Au.User_Name,
    Rj.Id,
    Rj.Output_Type,
    Rj.Job_Status
  ORDER BY S.Report_Name,
    Au.User_Name,
    Rj.Job_Status
  ) ,
  Temp AS
  (SELECT Report,
    Name,
    status,
    SUM(Pdfcount) Pdf_Count,
    SUM(Formatcount) Format_Count,
    SUM(Unformatcount) Unformat_Count,
    SUM(Pdfcount)                                              +SUM(Formatcount)+SUM(Unformatcount) COUNT,
    DENSE_RANK() Over (Partition BY Name Order By SUM(Pdfcount)+SUM(Formatcount)+SUM(Unformatcount) DESC) Rank
  FROM Qblock1
  GROUP BY Report,
    Name,
    status
  ORDER BY Name,
    Rank,
    Report
  )
SELECT Rownum ,
  Temp."REPORT",
  Temp."NAME",
  Temp."STATUS",
  Temp."PDF_COUNT",
  Temp."FORMAT_COUNT",
  Temp."UNFORMAT_COUNT",
  Temp."COUNT",
  Temp."RANK"
FROM Temp;