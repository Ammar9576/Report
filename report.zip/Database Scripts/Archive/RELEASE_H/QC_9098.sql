/**
 *  QC9098 : Below two procedure has been inserted into CIR_CONSTANTS (U124 only)
 */
Insert into NBC_CUST.CIR_CONSTANTS values
(
'emailFlag',
'Y'
);

