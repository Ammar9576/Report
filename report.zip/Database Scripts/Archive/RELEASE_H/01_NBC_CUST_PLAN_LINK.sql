CREATE OR REPLACE FORCE VIEW "NBC_CUST"."NEW_STEWARDSHIP_PLAN_LINK" ("PLAN_ID", "STEWARDSHIP_PLAN_LINK_ID", "STEWARDSHIP_PLAN_LINK_NAME","CHANNEL_ID")
AS
  SELECT pl.plan_id,
    spl.stewardship_plan_link_id,
    spl.stewardship_plan_link_name,spl.channel_id
  FROM PLAN_LINK pl,
    STEWARDSHIP_PLAN_LINK spl
  WHERE spl.stewardship_plan_link_id=pl.stewardship_plan_link_id;