DECLARE
  id_param NUMBER;
  id_searchval  NUMBER;
  searchid   NUMBER;
CURSOR search_id_cur
    IS
         SELECT DISTINCT id
          FROM
            (SELECT s.id
            FROM nbc_cust.search s,
              nbc_cust.report_jobs rj
            WHERE rj.deleted_flag =0
            AND s.ID              =rj.template_id
            AND s.deleted_flag    =0
            AND s.report_name LIKE 'SELLING NAME REVENUE REPORT'
            AND s.is_sticky='STICKY'
            UNION
            SELECT s.ID
            FROM nbc_cust.search s
            WHERE s.deleted_flag =0
            AND s.report_name LIKE 'SELLING NAME REVENUE REPORT'
            AND S.IS_STICKY IS NULL
            )
          WHERE id NOT IN
            (SELECT DISTINCT s.id
            from NBC_CUST.SEARCH_PARAM SP,
              nbc_cust.Search partition(search_active) S
            WHERE S.id =SP.SEARCH_ID
            AND S.REPORT_NAME LIKE 'SELLING NAME REVENUE REPORT'
            and SP.name like 'status'
            );
            --and id = 58364621;  
BEGIN

  SELECT MAX(ID)+1 INTO id_param FROM NBC_CUST.search_param;
  SELECT max(id)+1 INTO id_searchval from NBC_CUST.search_values ;

    OPEN search_id_cur;

    LOOP
       FETCH search_id_cur INTO searchid;
       EXIT WHEN search_id_cur%NOTFOUND;    
        INSERT INTO NBC_CUST.search_param (ID,NAME,SEARCH_ID) VALUES (id_param,'status',searchid);
        INSERT INTO NBC_CUST.search_values (ID,BOOLEANVALUE,DATEVALUE,NUMERICVALUE,STRINGVALUE,TYPE,PARAMETER_ID) VALUES (id_searchval,NULL,NULL,NULL,'704024456','STRING',id_param);
        COMMIT;
       id_param:=id_param+1;
       id_searchval:=id_searchval+1;
    END LOOP;
    CLOSE search_id_cur;
end;
