update NBC_CUST.last_run_job
set last_run_date =TO_TIMESTAMP('29-APR-1999 03.33.00.000000000 PM','DD-MON-YYYY HH.MI.SS.FF AM');