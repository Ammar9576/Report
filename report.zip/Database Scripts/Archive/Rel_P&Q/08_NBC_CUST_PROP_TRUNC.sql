truncate table nbc_cust.int_proposal_header_tbl;
truncate table nbc_cust.rows_table;
truncate table  nbc_cust.groups_table;
commit;
