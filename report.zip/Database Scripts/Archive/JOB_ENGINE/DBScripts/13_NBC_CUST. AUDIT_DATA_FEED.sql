create or replace
PROCEDURE                   NBC_CUST.AUDIT_DATA_FEED
IS
  createTimeInMillis NUMBER := 0;
  create_date TIMESTAMP;
  revID NUMBER := 101;
  -- recCount NUMBER := 0;
  -- Cursor to fetch the templates from search which is active.
  CURSOR SearchCursor
  IS
    SELECT *
    FROM nbc_cust.SEARCH
    WHERE deleted_flag = 0
    AND IS_STICKY     IS NULL
    ORDER BY id;
  -- Cursor to fetch all the active report group assoc records.
  CURSOR groupReportCursor
  IS
    SELECT *
    FROM nbc_cust.group_report_assoc
    WHERE deleted_flag = 0
    ORDER BY group_report_asc_id;
BEGIN
  -- SELECT COUNT(*) INTO recCount FROM SEARCH WHERE deleted_flag = 0 ORDER BY id;
  --DBMS_OUTPUT.PUT_LINE('count :'  || recCount);
  FOR searchRec IN searchCursor
  LOOP
    --DBMS_OUTPUT.PUT_LINE('searchRec.id :'  || searchRec.id);
    create_date := searchRec.search_date;
    --Get Date time in milli seconds as number on timezone EST
    SELECT to_number(to_date(TO_CHAR((CAST(create_date AS TIMESTAMP
  WITH TIME zone)) at TIME zone 'est', 'yyyy.mm.dd hh24:mi:ss'),'yyyy.mm.dd hh24:mi:ss') - to_date('01.01.1970','dd.mm.yyyy')) * (24 * 60 * 60 * 1000) AS timinmil
    INTO createTimeInMillis
    FROM dual;
    -- Insert a revision in revinfo table and this revision number will be used for audit each records further.
    INSERT INTO nbc_cust.revinfo VALUES
      (revID, createtimeinmillis
      );
    COMMIT;
    
    -- Insert the Search (templates to audit table with revision.
    INSERT
    INTO nbc_cust.search_audit
      (
        id,
        name,
        output_type,
        search_date,
        user_id,
        report_name,
        template_type,
        modify_user_id,
        modify_date,
        description,
        is_sticky,
        deleted_flag,
        CREATED_DATE,
        ver_rev,
        revtype,
        rev
      )
    SELECT se.*,
      NULL  AS ver_rev,
      0     AS revtype,
      revID AS rev
    FROM nbc_cust.search se
    WHERE se.id = searchRec.id;
    COMMIT;
    
    -- Insert the search parameter of the given search into search_param_audit table.
    INSERT
    INTO nbc_cust.search_param_audit
      (
        id,
        name,
        search_id,
        revtype,
        rev
      )
    SELECT sp.id,
      sp.name,
      NULL  AS search_id,
      0     AS revtype,
      revID AS rev
    FROM nbc_cust.search_param sp
    WHERE search_id=searchRec.id;
    COMMIT;
    
    --Insert the associated id's to search_param_assoc_audit for each search.
    INSERT
    INTO nbc_cust.search_param_assoc_audit
      (
        rev,
        search_id,
        id,
        revtype
      )
    SELECT revID AS rev,
      sp.search_id,
      sp.id,
      0 AS revtype
    FROM nbc_cust.search_param sp
    WHERE search_id=searchRec.id;
    COMMIT;
    -- Insert the values for search_values audit for each search.
    INSERT
    INTO nbc_cust.search_values_audit
      (
        id,
        booleanvalue,
        datevalue,
        numericvalue,
        stringvalue,
        type,
        parameter_id,
        revtype,
        rev
      )
    SELECT sv.id,
      sv.booleanvalue,
      sv.datevalue,
      sv.numericvalue,
      sv.stringvalue,
      sv.type,
      sv.parameter_id,
      0     AS revtype,
      revID AS rev
    FROM nbc_cust.search_values sv,
      nbc_cust.search_param sp
    WHERE sv.parameter_ID=sp.id
    AND sp.search_id     = searchRec.id;
    COMMIT;
    
    -- Insert the associated id's into search_values_assoc_audit
    INSERT
    INTO nbc_cust.search_values_assoc_audit
      (
        rev,
        parameter_id,
        id,
        revtype
      )
    SELECT revID AS rev,
      sv.parameter_id,
      sv.id,
      0 AS revtype
    FROM nbc_cust.search_values sv,
      nbc_cust.search_param sp
    WHERE sv.parameter_ID=sp.id
    AND sp.search_id     = searchRec.id;
    COMMIT;
    
    -- Insert the audit record for template to group into group_report_asc_tmpl_audit table.
    IF((upper(trim(searchRec.template_type)) = 'PUBLIC') OR (upper(trim(searchRec.template_type)) = 'ADMIN')) THEN
      INSERT
      INTO nbc_cust.group_report_asc_tmpl_audit
        (
          group_report_asc_id,
          template_id,
          created_date,
          modify_date,
          created_user_id,
          modify_user_id,
          deleted_flag,
          id,
          revtype,
          rev
        )
      SELECT gat.group_report_asc_id,
        gat.template_id,
        gat.created_date,
        gat.modify_date,
        gat.created_user_id,
        gat.modify_user_id,
        gat.deleted_flag,
        gat.id,
        0     AS revtype,
        revID AS rev
      FROM nbc_cust.group_report_asc_template gat
      WHERE gat.template_id = searchRec.id;
      COMMIT;
    END IF;
    --DBMS_OUTPUT.PUT_LINE('create_date : ' || create_date || ' createtimeinmillis :' || createtimeinmillis ||' revID ' || revID ||' search id ' || searchRec.id );
    revID := revID+1;
  END LOOP;
  revID := revID+1;
  FOR groupReportRec IN groupReportCursor
  LOOP
  create_date := groupReportRec.CREATED_DATE;
    SELECT to_number(to_date(TO_CHAR((CAST(create_date AS TIMESTAMP
  WITH TIME zone)) at TIME zone 'est', 'yyyy.mm.dd hh24:mi:ss'),'yyyy.mm.dd hh24:mi:ss') - to_date('01.01.1970','dd.mm.yyyy')) * (24 * 60 * 60 * 1000) AS timinmil
    INTO createTimeInMillis
    FROM dual;
    -- Insert a revision in revinfo table and this revision number will be used for audit each records further.
    INSERT INTO nbc_cust.revinfo VALUES
      (revID, createtimeinmillis
      );
    COMMIT;
    -- Insert the each report group assoc records into group_report_assoc_audit.
    INSERT
    INTO nbc_cust.group_report_assoc_audit
      (
        group_report_asc_id,
        group_id,
        report_name,
        created_date,
        modify_date,
        created_user_id,
        modify_user_id,
        deleted_flag,
        revtype,
        rev
      )
    SELECT gra.group_report_asc_id,
      gra.group_id,
      gra.report_name,
      gra.created_date,
      gra.modify_date,
      gra.created_user_id,
      gra.modify_user_id,
      gra.deleted_flag,
      0     AS revtype,
      revID AS rev
    FROM nbc_cust.group_report_assoc gra
    WHERE gra.group_report_asc_id = groupReportRec.group_report_asc_id;
    revID                        := revID+1;
  END LOOP;
END;