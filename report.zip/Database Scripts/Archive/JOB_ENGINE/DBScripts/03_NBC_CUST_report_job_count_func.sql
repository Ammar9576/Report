CREATE OR REPLACE FUNCTION NBC_CUST.REPORT_JOB_COUNT(
  P_STATUS IN VARCHAR2,  
  P_USER_ID IN VARCHAR2,  
  P_TABLE_NAME IN VARCHAR2 
) RETURN VARCHAR2 AS 

output varchar2(4000)  := null;
sqlString  varchar2(4000)  := null;
sqlString1 varchar2(4000)  := null;
sqlString2 varchar2(4000)  := null;
BEGIN

IF P_STATUS != 'STREAMED' and P_STATUS != 'OVERALL' THEN

  sqlString := 'select count(jobs.JOB_STATUS)  from '||P_TABLE_NAME||' jobs where jobs.JOB_STATUS = '''||p_status||''' and created_by = '''||P_USER_ID||''' and deleted_flag=0';
  EXECUTE IMMEDIATE sqlString into output;
    
ELSIF P_STATUS = 'OVERALL' THEN

   sqlString1 :='select count(jobs.JOB_STATUS) from '||P_TABLE_NAME||' jobs where jobs.JOB_STATUS in (''SCHEDULED'',''RUNNING'',''ABORTED'',''COMPLETED'') and created_by = '''||P_USER_ID||''' and deleted_flag=0';
   EXECUTE IMMEDIATE sqlString1 into output;

ELSE

  sqlString2 := 'select count(jobs.STREAMED_OUT)  from '||P_TABLE_NAME||' jobs where jobs.STREAMED_OUT = 0 and created_by = '''||P_USER_ID||''' and jobs.job_status =''COMPLETED'' and deleted_flag=0 ';
  EXECUTE IMMEDIATE sqlString2 into output;
END IF;

  RETURN output;
END REPORT_JOB_COUNT;