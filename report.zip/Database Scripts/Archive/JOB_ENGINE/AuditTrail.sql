ALTER TABLE NBC_CUST.GROUP_REPORT_ASSOC ADD
(
   DELETED_FLAG  NUMBER(1)
);

UPDATE NBC_CUST.GROUP_REPORT_ASSOC
SET DELETED_FLAG=0;

ALTER TABLE NBC_CUST.group_report_asc_template ADD
(
   DELETED_FLAG  NUMBER(1)
);

UPDATE NBC_CUST.group_report_asc_template
SET DELETED_FLAG=0;

ALTER TABLE NBC_CUST.group_report_asc_template ADD
(
   ID  NUMBER
);

DECLARE
   CURSOR group_report_temp_cur
   IS
      SELECT group_report_asc_id,template_id
      FROM NBC_CUST.group_report_asc_template;
BEGIN
   /* For each job fetched by the cursor... */
   UPDATE NBC_CUST.group_report_asc_template  temp
   SET ID = 0;
   COMMIT ;
   FOR group_report_temp_rec IN group_report_temp_cur
   LOOP
        UPDATE NBC_CUST.group_report_asc_template  temp
        SET ID =  (select max(ID)+1 from NBC_CUST.group_report_asc_template)
        WHERE temp.group_report_asc_id = group_report_temp_rec.group_report_asc_id
        AND temp.template_id=group_report_temp_rec.template_id;
   END LOOP;
  COMMIT;
END;

ALTER TABLE
NBC_CUST.group_report_asc_template
DISABLE constraint
SYS_C00557021;


