Update Nbc_Cust.Cir_Constants 
set value ='SLEUTH~CLOO,E~E!'
Where Key ='CHANGED_PROPS'
