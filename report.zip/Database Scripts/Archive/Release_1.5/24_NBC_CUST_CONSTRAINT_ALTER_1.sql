Change the foreign key constraint in the below tables, to make them point to NBC_CUST.SEARCH_PARTITION instead of NBC_CUST.SEARCH (in SQL Developer)
    a. NBC_CUST.SEARCH_PARAM
    b. NBC_CUST.GROUP_REPORT_ASC_TEMPLATE
    c. NBC_CUST.REPORT_JOBS
    d. NBC_CUST.REPORT_JOBS_TEMP
