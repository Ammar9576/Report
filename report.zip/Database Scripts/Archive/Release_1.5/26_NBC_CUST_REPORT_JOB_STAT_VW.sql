CREATE OR REPLACE FORCE VIEW "NBC_CUST"."REPORT_JOB_STATISTICS_VW" ("ID", "USER_ID", "COMPLETED_COUNT", "ABORTED_COUNT", "RUNNING_COUNT", "EXPIRED_COUNT", "SCHEDULED_COUNT", "CANCELLED_COUNT", "OVERALL_COUNT","STREAMED_OUT")
             AS 
WITH qblock AS
  (SELECT a.id,
    a.job_status status,
    --nvl(a.streamed_out,0) out,
    a.created_by user_id,
    --decode(a.job_status,'COMPLETED',1,0) completedcount,
     case when (decode(a.job_status,'COMPLETED',1,0)||nvl(a.streamed_out,0)) = 10 then 1
    else 0
    end compStOut0 ,
    case when (decode(a.job_status,'COMPLETED',1,0)||nvl(a.streamed_out,0)) = 11 then 1
    else 0
    end compStOut1,
    decode(a.job_status,'ABORTED',1,0) abortedcount,
    decode(a.job_status,'RUNNING',1,0) runningcount,
    decode(a.job_status,'SCHEDULED',1,0) scheduledcount,
    decode(a.job_status,'CANCELLED',1,0) cancelledcount,
    DECODE(a.job_status,'EXPIRED',1,0) expiredcount
  FROM nbc_cust.report_jobs a
  WHERE a.id         <>-1
  and a.deleted_flag <>1
  --AND a.created_by    ='18467'
  union 
    SELECT A.ID,
    a.job_status status ,
     --nvl(a.streamed_out,0) out,
    c.user_id user_id,
     case when (decode(a.job_status,'COMPLETED',1,0)||nvl(a.streamed_out,0)) = 10 then 1
    else 0
    end compStOut0 ,
    case when (decode(a.job_status,'COMPLETED',1,0)||nvl(a.streamed_out,0)) = 11 then 1
    else 0
    end compStOut1,
    --decode(a.job_status,'COMPLETED',1,0)||nvl(a.streamed_out,0) completedcount,
    decode(a.job_status,'ABORTED',1,0) abortedcount,
    decode(a.job_status,'RUNNING',1,0) runningcount,
    decode(a.job_status,'SCHEDULED',1,0) scheduledcount,
    decode(a.job_status,'CANCELLED',1,0) cancelledcount,
    DECODE(a.job_status,'EXPIRED',1,0) expiredcount
  FROM nbc_cust.report_jobs a,
    nbc_cust.report_schedules b,
    nbc_Cust.search c
  WHERE c.schedule_id =b.id
  AND b.id            =a.schedule_id
  AND c.template_type ='PRIVATE'
  AND a.id           <>-1
  and a.deleted_flag <>1
  --AND  c.user_id    ='18467'
  union 
  SELECT DISTINCT jobs.ID,
    jobs.job_status status,
     --nvl(jobs.streamed_out,0) out,
    usr.user_id user_id,
    --decode(jobs.job_status,'COMPLETED',1,0) completedcount,
     case when (decode(jobs.job_status,'COMPLETED',1,0)||nvl(jobs.streamed_out,0)) = 10 then 1
    else 0
    end compStOut0 ,
    case when (decode(jobs.job_status,'COMPLETED',1,0)||nvl(jobs.streamed_out,0)) = 11 then 1
    else 0
    end compStOut1,
    decode(jobs.job_status,'ABORTED',1,0) abortedcount,
    decode(jobs.job_status,'RUNNING',1,0) runningcount,
    decode(jobs.job_status,'SCHEDULED',1,0) scheduledcount,
    decode(jobs.job_status,'CANCELLED',1,0) cancelledcount,
    DECODE(jobs.job_status,'EXPIRED',1,0) expiredcount
  FROM onair.app_user usr
  INNER JOIN lbacsys.sa$user_groups securitygr1_
  ON usr.ident=securitygr1_.usr_name
  INNER JOIN lbacsys.sa$groups securitygr2_
  ON securitygr1_.group#=securitygr2_.group#
  INNER JOIN nbc_cust.group_report_assoc grouprepor3_
  ON securitygr2_.group#=grouprepor3_.group_id
  INNER JOIN nbc_cust.group_report_asc_template templates4_
  ON grouprepor3_.group_report_asc_id=templates4_.group_report_asc_id
  INNER JOIN nbc_cust.search search
  ON templates4_.template_id=search.id
  INNER JOIN nbc_cust.report_schedules schedules
  ON schedules.id=search.schedule_id
  INNER JOIN nbc_cust.report_jobs jobs
  ON jobs.schedule_id      =schedules.id
  WHERE search.id         <>-1
  AND search.deleted_flag <>1
  and search.template_type!='PRIVATE'
  --AND usr.user_id          ='18467'
  AND jobs.id             <>-1
  and jobs.deleted_flag   <>1
  ),
Temp AS(
SELECT 
  user_id,
  sum(compStOut0)+sum(compStOut1) completed_count,sum(abortedcount)+sum(cancelledcount) aborted_Count,sum(runningcount) running_count,sum(expiredcount) expired_count,sum(scheduledcount) scheduled_count,sum(cancelledcount) cancelled_count,sum(compStOut0)+sum(compStOut1)+sum(runningcount)+sum(abortedcount)+sum(scheduledcount)+sum(cancelledcount) overall_count,sum(compStOut0) streamed_out
FROM qblock
group by user_id
order by user_id )
SELECT Rownum ,
  Temp.*
FROM Temp;