CREATE OR REPLACE FORCE VIEW "NBC_CUST"."NEW_PLAN" ("PLAN_ID", "ADVERTISER_ID", "BRAND_ID", "CHANNEL_ID", "DEAL_YEAR_ID", "DEMO_POST_BUY_ID", "END_DATE", "END_QTR_ID", "GUARANTEED_CODE", "HH_POST_BUY_ID", "MARKETPLACE_CODE", "PLAN_NAME", "PLAN_APPROVAL_STATUS_CODE", "PLAN_CLASS_CODE", "PLAN_STATUS_CODE", "RATE_TYPE_CODE", "RATING_SOURCE_CODE", "RATING_STREAM_CODE", "SALES_TEAM_ID", "START_DATE", "START_QTR_ID", "TARGET_GROUP_ID", "PLAN_VERSION_NUMBER", "STEWARDSHIP_PLAN_LINK_ID", "STEWARDSHIP_PLAN_LINK_NAME", "ACCOUNT_EXEC_ID")
                                           AS
  SELECT plan0_.PLAN_ID                    AS PLAN_ID,
    plan0_.ADVERTISER_ID                   AS ADVERTISER_ID,
    plan0_.BRAND_ID                        AS BRAND_ID,
    plan0_.CHANNEL_ID                      AS CHANNEL_ID,
    plan0_.DEAL_YEAR_ID                    AS DEAL_YEAR_ID,
    plan0_.DEMO_POST_BUY_ID                AS DEMO_POST_BUY_ID,
    plan0_.END_DATE                        AS END_DATE,
    plan0_.END_QTR_ID                      AS END_QTR_ID,
    plan0_.GUARANTEED_CODE                 AS GUARANTEED_CODE,
    plan0_.HH_POST_BUY_ID                  AS HH_POST_BUY_ID,
    plan0_.marketplace_code                AS marketplace_code,
    NVL(plan1_.plan_name,plan0_.plan_name) AS plan_name,
    --plan0_.PLAN_NAME                 AS PLAN_NAME,
    plan0_.PLAN_APPROVAL_STATUS_CODE AS PLAN_APPROVAL_STATUS_CODE,
    plan0_.PLAN_CLASS_CODE           AS PLAN_CLASS_CODE,
    plan0_.PLAN_STATUS_CODE          AS PLAN_STATUS_CODE,
    plan0_.RATE_TYPE_CODE            AS RATE_TYPE_CODE,
    plan0_.RATING_SOURCE_CODE        AS RATING_SOURCE_CODE,
    plan0_.RATING_STREAM_CODE        AS RATING_STREAM_CODE,
    plan0_.SALES_TEAM_ID             AS SALES_TEAM_ID,
    plan0_.START_DATE                AS START_DATE,
    plan0_.start_qtr_id              AS start_qtr_id,
    plan0_.target_group_id           AS target_group_id ,
    SUBSTR((
    CASE
      WHEN (SELECT Sys_Param.Param_Value
        FROM Sys_Param
        WHERE upper(Sys_Param.Param_Name) = upper('SALES_PLAN_REVISION_FIRST_NUMBER')) < plan0_.REVISION_NO
      THEN TO_CHAR( plan0_.Original_Plan_Id)
      ELSE TO_CHAR( plan0_.Original_Plan_Id)
        || NVL(
        (SELECT ml_translation.value
        FROM ml_translation
        WHERE ml_translation.ml_text_id   =63710
        AND ml_translation.cd_language_id = shell_pkg.get_language_id()
        ),
        (SELECT ml_text.default_value FROM ml_text WHERE ml_text.ml_text_id =63710
        ))
        || TO_CHAR(plan0_.version_no)
    END),1,250) AS plan_version_number ,
    planlinks2_.stewardship_plan_link_id ,
    planlinks2_.stewardship_plan_link_name ,
    planhistor3_.account_exec_id
  FROM onair.plan plan0_ ,
    onair.plan_rev plan1_ ,
    nbc_cust.new_stewardship_plan_link planlinks2_ ,
    onair.plan_ae_history_rev_vw planhistor3_
  WHERE plan0_.plan_id             =planhistor3_.plan_id
  AND plan0_.plan_id               =plan1_.plan_id (+)
  AND plan0_.plan_id               =planlinks2_.plan_id (+)
  AND plan0_.plan_status_code NOT IN ('1336009','1336008' )
  AND planhistor3_.ae_active_code  ='1456000'
  AND plan0_.plan_id              <>-1;