create or replace
FUNCTION                   NBC_CUST.REPORT_JOB_COUNT(
      P_STATUS     IN VARCHAR2,
      P_USER_ID    IN VARCHAR2,
      P_TABLE_NAME IN VARCHAR2 )
    RETURN VARCHAR2
  AS
    output     VARCHAR2(4000) := NULL;
    sqlString  VARCHAR2(4000) := NULL;
    sqlString1 VARCHAR2(4000) := NULL;
    sqlString2 VARCHAR2(4000) := NULL;
  BEGIN
    IF P_STATUS != 'STREAMED' AND P_STATUS != 'OVERALL' THEN
      sqlString := 'SELECT count(JOBS.JOB_STATUS) FROM (SELECT a.* FROM '||P_TABLE_NAME||' a WHERE a.created_by='''||P_USER_ID||''' UNION SELECT a.* FROM '||P_TABLE_NAME||' a, nbc_cust.report_schedules b, nbc_Cust.search c WHERE c.schedule_id=b.id AND b.id=a.schedule_id AND c.template_type=''PRIVATE'' AND c.user_id='''||P_USER_ID||''' UNION SELECT DISTINCT jobs.* FROM ONAIR.APP_USER usr INNER JOIN LBACSYS.SA$USER_GROUPS securitygr1_ ON usr.IDENT=securitygr1_.USR_NAME INNER JOIN LBACSYS.SA$GROUPS securitygr2_ ON securitygr1_.GROUP#=securitygr2_.GROUP# INNER JOIN NBC_CUST.GROUP_REPORT_ASSOC grouprepor3_ ON securitygr2_.GROUP#=grouprepor3_.GROUP_ID INNER JOIN NBC_CUST.GROUP_REPORT_ASC_TEMPLATE templates4_ ON grouprepor3_.GROUP_REPORT_ASC_ID=templates4_.GROUP_REPORT_ASC_ID INNER JOIN nbc_cust.Search search ON templates4_.TEMPLATE_ID=search.id INNER JOIN nbc_cust.report_schedules schedules ON schedules.id=search.schedule_id INNER JOIN '||P_TABLE_NAME||' jobs ON jobs.schedule_id=schedules.id WHERE search.id<>-1 AND search.deleted_flag <>1 AND search.template_type!=''PRIVATE'' AND usr.user_id  ='''||P_USER_ID||''' ) JOBS WHERE JOBS.id<>-1 AND JOBS.deleted_Flag <>1 and JOBS.JOB_STATUS = '''||p_status||'''';
      EXECUTE IMMEDIATE sqlString INTO output;
    ELSIF P_STATUS = 'OVERALL' THEN
      sqlString1  :='SELECT count(JOB_STATUS) FROM (SELECT a.* FROM '||P_TABLE_NAME||' a WHERE a.created_by='''||P_USER_ID||''' UNION SELECT a.* FROM '||P_TABLE_NAME||' a, nbc_cust.report_schedules b, nbc_Cust.search c WHERE c.schedule_id=b.id AND b.id=a.schedule_id AND c.template_type=''PRIVATE'' AND c.user_id='''||P_USER_ID||''' UNION SELECT DISTINCT jobs.* FROM ONAIR.APP_USER usr INNER JOIN LBACSYS.SA$USER_GROUPS securitygr1_ ON usr.IDENT=securitygr1_.USR_NAME INNER JOIN LBACSYS.SA$GROUPS securitygr2_ ON securitygr1_.GROUP#=securitygr2_.GROUP# INNER JOIN NBC_CUST.GROUP_REPORT_ASSOC grouprepor3_ ON securitygr2_.GROUP#=grouprepor3_.GROUP_ID INNER JOIN NBC_CUST.GROUP_REPORT_ASC_TEMPLATE templates4_ ON grouprepor3_.GROUP_REPORT_ASC_ID=templates4_.GROUP_REPORT_ASC_ID INNER JOIN nbc_cust.Search search ON templates4_.TEMPLATE_ID=search.id INNER JOIN nbc_cust.report_schedules schedules ON schedules.id=search.schedule_id INNER JOIN '||P_TABLE_NAME||' jobs ON jobs.schedule_id=schedules.id WHERE search.id<>-1 AND search.deleted_flag <>1 AND search.template_type!=''PRIVATE'' AND usr.user_id  ='''||P_USER_ID||''' ) WHERE id<>-1 AND deleted_Flag <>1 and JOB_STATUS in (''SCHEDULED'',''RUNNING'',''ABORTED'',''COMPLETED'')';
      EXECUTE IMMEDIATE sqlString1 INTO output;
    ELSE
      sqlString2 := 'SELECT count(STREAMED_OUT) FROM (SELECT a.* FROM '||P_TABLE_NAME||' a WHERE a.created_by='''||P_USER_ID||''' UNION SELECT a.* FROM '||P_TABLE_NAME||' a, nbc_cust.report_schedules b, nbc_Cust.search c WHERE c.schedule_id=b.id AND b.id=a.schedule_id AND c.template_type=''PRIVATE'' AND c.user_id='''||P_USER_ID||''' UNION SELECT DISTINCT jobs.* FROM ONAIR.APP_USER usr INNER JOIN LBACSYS.SA$USER_GROUPS securitygr1_ ON usr.IDENT=securitygr1_.USR_NAME INNER JOIN LBACSYS.SA$GROUPS securitygr2_ ON securitygr1_.GROUP#=securitygr2_.GROUP# INNER JOIN NBC_CUST.GROUP_REPORT_ASSOC grouprepor3_ ON securitygr2_.GROUP#=grouprepor3_.GROUP_ID INNER JOIN NBC_CUST.GROUP_REPORT_ASC_TEMPLATE templates4_ ON grouprepor3_.GROUP_REPORT_ASC_ID=templates4_.GROUP_REPORT_ASC_ID INNER JOIN nbc_cust.Search search ON templates4_.TEMPLATE_ID=search.id INNER JOIN nbc_cust.report_schedules schedules ON schedules.id=search.schedule_id INNER JOIN '||P_TABLE_NAME||' jobs ON jobs.schedule_id=schedules.id WHERE search.id<>-1 AND search.deleted_flag <>1 AND search.template_type!=''PRIVATE'' AND usr.user_id  ='''||P_USER_ID||''' ) WHERE id<>-1 AND deleted_Flag <>1 and JOB_STATUS =''COMPLETED'' and STREAMED_OUT = 0';
      EXECUTE IMMEDIATE sqlString2 INTO output;
    END IF;
    RETURN output;
  END report_job_count;