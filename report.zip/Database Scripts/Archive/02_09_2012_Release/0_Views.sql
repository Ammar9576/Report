CREATE OR REPLACE FORCE VIEW "NBC_CUST"."NEW_LIGHT_WEIGHT_PLAN_VW"
                 AS
SELECT p.plan_id,
  p.plan_name,
  p.START_QTR_ID,
  p.END_QTR_ID,
  p.START_DATE,
  p.END_DATE,
  ps.code plan_status_id,
  ps.plan_status plan_status_name,
  DECODE(upper(gua.DESCRIPTION),'GUARANTEED','Y','N') guaranteedCode,
  u.user_name account_executive,
  u.user_id account_executive_id,
  rs.code rating_stream_id,
  rs.description rating_stream_name,
  mp.code market_place_id,
  mp.description market_place_name,
  dpm.POSTING_METHODOLOGY_NAME dbm_name,
  dpm.posting_methodology_id dpm_id,
  hpm.POSTING_METHODOLOGY_NAME hbm_name,
  hpm.posting_methodology_id hpm_id,
  ad.advertiser_id,
  ad.advertiser_name,
  c.channel_id channel_id,
  c.channel_name channel_name,
  pas.CODE plan_approval_status_id,
  pas.DESCRIPTION plan_approval_status
FROM onair.plan p,
  nbc_Cust.PLAN_STATUS_CIR_VW ps,
  onair.codesc gua,
  onair.ADVERTISER ad,
  onair.app_user u,
  onair.MARKETPLACE_CVW mp,
  onair.RATING_STREAM_CVW rs,
  onair.POSTING_METHODOLOGY hpm,
  onair.POSTING_METHODOLOGY dpm,
  onair.channel c,
  onair.PLAN_APPROVAL_STATUS_CVW pas
WHERE ps.code(+)       =p.PLAN_STATUS_CODE
AND gua.CODE     (+)   = p.GUARANTEED_CODE
AND ad.ADVERTISER_ID(+)=p.ADVERTISER_ID
AND u.user_id    (+)   =p.account_exec_id
AND rs.code   (+)      =p.RATING_STREAM_CODE
AND hpm.POSTING_METHODOLOGY_ID   (+)     =p.HH_POST_BUY_ID
AND dpm.POSTING_METHODOLOGY_ID  (+)      =p.DEMO_POST_BUY_ID
AND mp.CODE       (+)  = p.MARKETPLACE_CODE
AND c.channel_id  (+)  =p.CHANNEL_ID
AND pas.code     (+)   =p.PLAN_APPROVAL_STATUS_CODE
and lower(ps.plan_status)<>'occasional';



CREATE OR REPLACE FORCE VIEW "NBC_CUST"."NEW_STEWARDSHIP_PLAN_LINK"
                 AS
select pl.plan_id,spl.stewardship_plan_link_id,spl.stewardship_plan_link_name from PLAN_LINK pl, STEWARDSHIP_PLAN_LINK spl
where spl.stewardship_plan_link_id=pl.stewardship_plan_link_id;
