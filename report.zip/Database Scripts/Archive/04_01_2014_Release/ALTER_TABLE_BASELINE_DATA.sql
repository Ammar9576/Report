alter table NBC_CUST.baseline_data add(RATING_STREAM_CODE NUMBER(9,0) DEFAULT 0 );
alter table NBC_CUST.baseline_data add(RATING_STREAM VARCHAR2(100 BYTE));
Commit;  