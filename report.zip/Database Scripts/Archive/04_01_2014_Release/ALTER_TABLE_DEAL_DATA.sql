alter table NBC_CUST.DEAL_DATA add(PLAN_ID NUMBER(9,0) DEFAULT 0 );
Commit;  