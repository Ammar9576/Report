CREATE TABLE NBC_CUST.DEAL_DATA
  (
    IDENTIFICATION_CODE               NUMBER(9,0) NOT NULL ENABLE,
    QUARTER_NAME                      VARCHAR2(100 BYTE),
    PERIOD_START_DATE                 DATE  NOT NULL ENABLE,
    PERIOD_END_DATE                   DATE  NOT NULL ENABLE,
    IMP                               NUMBER(22,7) DEFAULT 0,
    REVENUE                           NUMBER(22,7)  DEFAULT 0,
    AGENCY_CODE                       NUMBER(9,0) DEFAULT 0,
    AGENCY                            VARCHAR2(100 BYTE) DEFAULT 0,
    ADVERTISOR_CODE                   NUMBER(9,0) DEFAULT 0,
    ADVERTISOR                        VARCHAR2(100 BYTE) DEFAULT 0,
    MARKET_PLACE_CODE                 NUMBER(9,0) DEFAULT 0,
    MARKET_PLACE                      VARCHAR2(100 BYTE) DEFAULT 0,
    SELLING_TITLE_EXTERNAL_ID         NUMBER(9,0)DEFAULT 0,           
    SELLING_NAME                      VARCHAR2(100 BYTE),
    EXTERNAL_DEAL_ID                  NUMBER(9,0) DEFAULT 0,
    PLAN_NAME                         VARCHAR2(100 BYTE),
    PROPERTY_ID                       NUMBER(9,0)DEFAULT 0,
    PROPERTY_NAME                     VARCHAR2(100 BYTE),
    PLAN_STATUS_CODE                  NUMBER(9,0) DEFAULT 0,
    CONTRACT_TYPE                     VARCHAR2(100 BYTE),
    P18_49_IMPRESSIONS                NUMBER(22,7) DEFAULT 0,
    F18_49_IMPRESSIONS                NUMBER(22,7) DEFAULT 0,
    UNITS                             NUMBER(22,7) DEFAULT 0,
    DAYPART_CODE                      NUMBER(9,0) DEFAULT 0,
    DAYPART                           VARCHAR2(100 BYTE),
    SUB_STATUSES_CODE                 VARCHAR2(100 BYTE),
    SUB_STATUSES                      VARCHAR2(100 BYTE),
    EXECUTION_DATE                    DATE DEFAULT CURRENT_DATE,
    EXECUTION_TIMESTAMP               TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "DEAL_DATA_PK" PRIMARY KEY(IDENTIFICATION_CODE) ENABLE
  );
  
CREATE SEQUENCE NBC_CUST.DEAL_DATA_SEQ;

CREATE OR REPLACE TRIGGER NBC_CUST.DEAL_DATA_TRIGGER 
BEFORE INSERT ON NBC_CUST.DEAL_DATA 
FOR EACH ROW
BEGIN
  SELECT NBC_CUST.DEAL_DATA_SEQ.NEXTVAL
  INTO   :new.identification_code
  FROM   dual;
END;

