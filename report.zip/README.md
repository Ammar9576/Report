CIR
===

Reporting Dashboard Source code Repository

For detailed setup instructions, see the file: [site/markdown/setup-dev.md.vm](site/markdown/setup-dev.md.vm)

The most recent information is in the `develop` branch.

The top level documentation is here: [site/markdown/index.md.vm](site/markdown/index.md.vm)
