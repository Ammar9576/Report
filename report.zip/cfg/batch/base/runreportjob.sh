#!/bin/bash


java -Xms512m -Xmx1024m  -cp "$BATCH_HOME/$1/jars/*:$BATCH_HOME/$1/app/CIR-1.0.jar" main.java.batch.com.ge.nbcuni.job.ReportJobBatch $2 $3
